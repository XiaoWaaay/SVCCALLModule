/* ============================================================================
 * main.c - SVCModule KPM 入口文件
 * ============================================================================
 * 版本: 3.0.0
 * 描述: KPM 模块入口, 包含 init/control/exit 函数
 *       kpm_control0 提供完整的用户空间命令交互接口
 * ============================================================================ */

#include <compiler.h>
#include <kpmodule.h>
#include <linux/printk.h>
#include <linux/string.h>
#include "svc_tracer.h"

/* KPM 模块元信息 */
KPM_NAME("svc-tracer");
KPM_VERSION(SVC_TRACER_VERSION);
KPM_LICENSE("GPL v2");
KPM_AUTHOR("svc-tracer team");
KPM_DESCRIPTION("ARM64 syscall tracer with anti-debug detection for KernelPatch");

/* ---- 辅助宏: 安全 snprintf 到用户空间输出缓冲区 ---- */
#define OUT_MSG(fmt, ...) \
    do { \
        if (out_msg && outlen > 0) { \
            snprintf(out_msg, outlen, fmt, ##__VA_ARGS__); \
        } \
    } while (0)

/* ---- 辅助函数: 字符串比较 ---- */
static int str_starts_with(const char *str, const char *prefix)
{
    int len = strlen(prefix);
    return (strncmp(str, prefix, len) == 0);
}

/* ---- 辅助函数: 跳过前导空格 ---- */
static const char *skip_spaces(const char *s)
{
    while (*s == ' ' || *s == '\t')
        s++;
    return s;
}

/* ---- 辅助函数: 简单 atoi ---- */
static int simple_atoi(const char *s)
{
    int val = 0;
    int neg = 0;

    if (*s == '-') {
        neg = 1;
        s++;
    }
    while (*s >= '0' && *s <= '9') {
        val = val * 10 + (*s - '0');
        s++;
    }
    return neg ? -val : val;
}

/* ============================================================================
 * kpm_init - 模块初始化入口
 * ============================================================================
 * 由 KernelPatch 在加载模块时调用。
 * 参数: args - 用户提供的初始化参数字符串 (可为 NULL)
 * 返回: 0 成功, 负值失败
 * ============================================================================ */
static long kpm_init(const char *args, const char *__user reserved, void *__user outbuf)
{
    int ret;

    pr_info("[svc-tracer] initializing v%s\n", SVC_TRACER_VERSION);

    /* 1. 初始化符号解析器 (最先, 其他模块依赖内核符号) */
    ret = symbol_resolver_init();
    if (ret < 0) {
        pr_err("[svc-tracer] symbol_resolver_init failed: %d\n", ret);
        return ret;
    }

    /* 2. 初始化事件日志缓冲区 */
    ret = event_logger_init();
    if (ret < 0) {
        pr_err("[svc-tracer] event_logger_init failed: %d\n", ret);
        return ret;
    }

    /* 3. 初始化调用者解析器 */
    ret = caller_resolver_init();
    if (ret < 0) {
        pr_err("[svc-tracer] caller_resolver_init failed: %d\n", ret);
        goto fail_caller;
    }

    /* 4. 初始化 maps 缓存 */
    ret = maps_cache_init();
    if (ret < 0) {
        pr_err("[svc-tracer] maps_cache_init failed: %d\n", ret);
        goto fail_maps;
    }

    /* 5. 初始化包名解析器 */
    ret = pkg_resolver_init();
    if (ret < 0) {
        pr_err("[svc-tracer] pkg_resolver_init failed: %d\n", ret);
        goto fail_pkg;
    }

    /* 6. 初始化 syscall 监控器 (初始化默认配置) */
    ret = syscall_monitor_init();
    if (ret < 0) {
        pr_err("[svc-tracer] syscall_monitor_init failed: %d\n", ret);
        goto fail_monitor;
    }

    /* 7. 初始化 hook 引擎 (不安装 hook, 等待用户命令) */
    ret = hook_engine_init();
    if (ret < 0) {
        pr_err("[svc-tracer] hook_engine_init failed: %d\n", ret);
        goto fail_hook;
    }

    /* 8. 初始化文件日志 */
    ret = file_logger_init();
    if (ret < 0) {
        pr_err("[svc-tracer] file_logger_init failed (non-fatal): %d\n", ret);
        /* 文件日志失败不影响核心功能 */
    }

    /* 9. 解析初始化参数 (可选) */
    if (args && strlen(args) > 0) {
        pr_info("[svc-tracer] init args: %s\n", args);
        /* 预留: 未来可在此解析初始化参数 */
    }

    pr_info("[svc-tracer] initialized successfully\n");
    return 0;

fail_hook:
fail_monitor:
fail_pkg:
    maps_cache_destroy();
fail_maps:
fail_caller:
    event_logger_destroy();
    return ret;
}

/* ============================================================================
 * kpm_control0 - 模块控制接口
 * ============================================================================
 * 由用户空间通过 KernelPatch 的 ctl 接口调用。
 * 参数:
 *   args    - 用户命令字符串
 *   out_msg - 输出缓冲区 (用户空间地址)
 *   outlen  - 输出缓冲区长度
 * 返回: 0 成功, 负值错误
 * ============================================================================ */
static long kpm_control0(const char *args, char *__user out_msg, int outlen)
{
    const char *cmd;
    const char *param;

    if (!args || strlen(args) == 0) {
        OUT_MSG("{\"error\":\"empty command\"}");
        return -1;
    }

    cmd = skip_spaces(args);

    /* ================================================================
     * status - 返回当前状态
     * ================================================================ */
    if (strcmp(cmd, "status") == 0) {
        int pending = event_logger_pending();
        OUT_MSG("{\"status\":\"ok\",\"version\":\"%s\","
                "\"running\":%d,\"pid_count\":%d,"
                "\"filter_uid\":%d,\"filter_pkg\":\"%s\","
                "\"filter_comm\":\"%s\","
                "\"category_mask\":%d,\"syscall_filter_count\":%d,"
                "\"pending_events\":%d,\"hooks\":%d,"
                "\"capture_args\":%d,\"capture_caller\":%d,"
                "\"capture_bt\":%d,\"capture_retval\":%d,"
                "\"detect_antidebug\":%d,"
                "\"file_log\":%d}",
                SVC_TRACER_VERSION,
                g_config.running, g_config.pid_count,
                g_config.filter_uid, g_config.filter_pkg,
                g_config.filter_comm,
                g_config.category_mask, g_config.filtered_syscall_count,
                pending, hook_get_count(),
                g_config.capture_args, g_config.capture_caller,
                g_config.capture_backtrace, g_config.capture_retval,
                g_config.detect_antidebug,
                g_config.file_log_enabled);
        return 0;
    }

    /* ================================================================
     * version - 返回版本
     * ================================================================ */
    if (strcmp(cmd, "version") == 0) {
        OUT_MSG("{\"version\":\"%s\"}", SVC_TRACER_VERSION);
        return 0;
    }

    /* ================================================================
     * start - 启动监控
     * ================================================================ */
    if (strcmp(cmd, "start") == 0) {
        if (g_config.running) {
            OUT_MSG("{\"status\":\"already_running\"}");
            return 0;
        }
        if (hook_get_count() == 0) {
            /* 默认安装 slim hook 集 */
            hook_install_slim();
        }
        g_config.running = 1;
        OUT_MSG("{\"status\":\"started\",\"hooks\":%d}", hook_get_count());
        pr_info("[svc-tracer] monitoring started\n");
        return 0;
    }

    /* ================================================================
     * stop - 停止监控
     * ================================================================ */
    if (strcmp(cmd, "stop") == 0) {
        g_config.running = 0;
        OUT_MSG("{\"status\":\"stopped\"}");
        pr_info("[svc-tracer] monitoring stopped\n");
        return 0;
    }

    /* ================================================================
     * pid add <pid> / pid remove <pid> / pid clear / pid list
     * ================================================================ */
    if (str_starts_with(cmd, "pid ")) {
        param = skip_spaces(cmd + 4);

        if (str_starts_with(param, "add ")) {
            int pid_val = simple_atoi(skip_spaces(param + 4));
            if (pid_val <= 0) {
                OUT_MSG("{\"error\":\"invalid pid\"}");
                return -1;
            }
            if (g_config.pid_count >= MAX_MONITORED_PIDS) {
                OUT_MSG("{\"error\":\"pid list full\",\"max\":%d}", MAX_MONITORED_PIDS);
                return -1;
            }
            /* 检查重复 */
            int i;
            for (i = 0; i < g_config.pid_count; i++) {
                if (g_config.monitored_pids[i] == pid_val) {
                    OUT_MSG("{\"status\":\"already_exists\",\"pid\":%d}", pid_val);
                    return 0;
                }
            }
            g_config.monitored_pids[g_config.pid_count++] = pid_val;
            OUT_MSG("{\"status\":\"added\",\"pid\":%d,\"count\":%d}",
                    pid_val, g_config.pid_count);
            return 0;
        }

        if (str_starts_with(param, "remove ")) {
            int pid_val = simple_atoi(skip_spaces(param + 7));
            int i, found = 0;
            for (i = 0; i < g_config.pid_count; i++) {
                if (g_config.monitored_pids[i] == pid_val) {
                    /* 移除: 用最后一个元素填充 */
                    g_config.monitored_pids[i] =
                        g_config.monitored_pids[--g_config.pid_count];
                    found = 1;
                    break;
                }
            }
            if (found)
                OUT_MSG("{\"status\":\"removed\",\"pid\":%d,\"count\":%d}",
                        pid_val, g_config.pid_count);
            else
                OUT_MSG("{\"error\":\"pid not found\",\"pid\":%d}", pid_val);
            return found ? 0 : -1;
        }

        if (strcmp(param, "clear") == 0) {
            g_config.pid_count = 0;
            OUT_MSG("{\"status\":\"pid_list_cleared\"}");
            return 0;
        }

        if (strcmp(param, "list") == 0) {
            int off = 0;
            int i;
            off += snprintf(out_msg + off, outlen - off, "{\"pids\":[");
            for (i = 0; i < g_config.pid_count; i++) {
                if (i > 0)
                    off += snprintf(out_msg + off, outlen - off, ",");
                off += snprintf(out_msg + off, outlen - off, "%d",
                                g_config.monitored_pids[i]);
            }
            off += snprintf(out_msg + off, outlen - off, "],\"count\":%d}",
                            g_config.pid_count);
            return 0;
        }

        OUT_MSG("{\"error\":\"unknown pid command\"}");
        return -1;
    }

    /* ================================================================
     * uid set <uid> / uid clear
     * ================================================================ */
    if (str_starts_with(cmd, "uid ")) {
        param = skip_spaces(cmd + 4);

        if (str_starts_with(param, "set ")) {
            int uid_val = simple_atoi(skip_spaces(param + 4));
            g_config.filter_uid = uid_val;
            OUT_MSG("{\"status\":\"uid_set\",\"uid\":%d}", uid_val);
            return 0;
        }

        if (strcmp(param, "clear") == 0) {
            g_config.filter_uid = -1;
            OUT_MSG("{\"status\":\"uid_cleared\"}");
            return 0;
        }

        OUT_MSG("{\"error\":\"unknown uid command\"}");
        return -1;
    }

    /* ================================================================
     * app set <package> / app clear
     * ================================================================ */
    if (str_starts_with(cmd, "app ")) {
        param = skip_spaces(cmd + 4);

        if (str_starts_with(param, "set ")) {
            const char *pkg = skip_spaces(param + 4);
            int len = strlen(pkg);
            if (len == 0 || len >= MAX_PKG_LEN) {
                OUT_MSG("{\"error\":\"invalid package name\"}");
                return -1;
            }
            memset(g_config.filter_pkg, 0, MAX_PKG_LEN);
            strncpy(g_config.filter_pkg, pkg, MAX_PKG_LEN - 1);
            /* 尝试解析包名对应的 UID */
            int resolved_uid = pkg_resolve_pkg_to_uid(pkg);
            if (resolved_uid >= 0) {
                g_config.filter_uid = resolved_uid;
                OUT_MSG("{\"status\":\"app_set\",\"pkg\":\"%s\",\"uid\":%d}",
                        pkg, resolved_uid);
            } else {
                OUT_MSG("{\"status\":\"app_set\",\"pkg\":\"%s\",\"uid\":\"unresolved\"}",
                        pkg);
            }
            return 0;
        }

        if (strcmp(param, "clear") == 0) {
            memset(g_config.filter_pkg, 0, MAX_PKG_LEN);
            OUT_MSG("{\"status\":\"app_cleared\"}");
            return 0;
        }

        OUT_MSG("{\"error\":\"unknown app command\"}");
        return -1;
    }

    /* ================================================================
     * comm set <name> / comm clear
     * ================================================================ */
    if (str_starts_with(cmd, "comm ")) {
        param = skip_spaces(cmd + 5);

        if (str_starts_with(param, "set ")) {
            const char *name = skip_spaces(param + 4);
            if (strlen(name) == 0 || strlen(name) >= MAX_COMM_LEN) {
                OUT_MSG("{\"error\":\"invalid comm name\"}");
                return -1;
            }
            memset(g_config.filter_comm, 0, MAX_COMM_LEN);
            strncpy(g_config.filter_comm, name, MAX_COMM_LEN - 1);
            OUT_MSG("{\"status\":\"comm_set\",\"comm\":\"%s\"}", name);
            return 0;
        }

        if (strcmp(param, "clear") == 0) {
            memset(g_config.filter_comm, 0, MAX_COMM_LEN);
            OUT_MSG("{\"status\":\"comm_cleared\"}");
            return 0;
        }

        OUT_MSG("{\"error\":\"unknown comm command\"}");
        return -1;
    }

    /* ================================================================
     * syscall add <nr> / syscall remove <nr> / syscall clear / syscall list
     * ================================================================ */
    if (str_starts_with(cmd, "syscall ")) {
        param = skip_spaces(cmd + 8);

        if (str_starts_with(param, "add ")) {
            int nr = simple_atoi(skip_spaces(param + 4));
            if (nr < 0) {
                OUT_MSG("{\"error\":\"invalid syscall number\"}");
                return -1;
            }
            if (g_config.filtered_syscall_count >= MAX_FILTERED_SYSCALLS) {
                OUT_MSG("{\"error\":\"syscall filter list full\"}");
                return -1;
            }
            int i;
            for (i = 0; i < g_config.filtered_syscall_count; i++) {
                if (g_config.filtered_syscalls[i] == nr) {
                    OUT_MSG("{\"status\":\"already_exists\",\"nr\":%d}", nr);
                    return 0;
                }
            }
            g_config.filtered_syscalls[g_config.filtered_syscall_count++] = nr;
            OUT_MSG("{\"status\":\"added\",\"nr\":%d,\"count\":%d}",
                    nr, g_config.filtered_syscall_count);
            return 0;
        }

        if (str_starts_with(param, "remove ")) {
            int nr = simple_atoi(skip_spaces(param + 7));
            int i, found = 0;
            for (i = 0; i < g_config.filtered_syscall_count; i++) {
                if (g_config.filtered_syscalls[i] == nr) {
                    g_config.filtered_syscalls[i] =
                        g_config.filtered_syscalls[--g_config.filtered_syscall_count];
                    found = 1;
                    break;
                }
            }
            if (found)
                OUT_MSG("{\"status\":\"removed\",\"nr\":%d}", nr);
            else
                OUT_MSG("{\"error\":\"syscall not found\",\"nr\":%d}", nr);
            return found ? 0 : -1;
        }

        if (strcmp(param, "clear") == 0) {
            g_config.filtered_syscall_count = 0;
            OUT_MSG("{\"status\":\"syscall_filter_cleared\"}");
            return 0;
        }

        if (strcmp(param, "list") == 0) {
            int off = 0;
            int i;
            off += snprintf(out_msg + off, outlen - off, "{\"syscalls\":[");
            for (i = 0; i < g_config.filtered_syscall_count; i++) {
                if (i > 0)
                    off += snprintf(out_msg + off, outlen - off, ",");
                off += snprintf(out_msg + off, outlen - off, "%d",
                                g_config.filtered_syscalls[i]);
            }
            off += snprintf(out_msg + off, outlen - off, "],\"count\":%d}",
                            g_config.filtered_syscall_count);
            return 0;
        }

        OUT_MSG("{\"error\":\"unknown syscall command\"}");
        return -1;
    }

    /* ================================================================
     * cat set <mask> / cat reset
     * ================================================================ */
    if (str_starts_with(cmd, "cat ")) {
        param = skip_spaces(cmd + 4);

        if (str_starts_with(param, "set ")) {
            int mask = simple_atoi(skip_spaces(param + 4));
            g_config.category_mask = (unsigned char)(mask & 0xFF);
            OUT_MSG("{\"status\":\"category_set\",\"mask\":%d}",
                    g_config.category_mask);
            return 0;
        }

        if (strcmp(param, "reset") == 0) {
            g_config.category_mask = SC_CAT_ALL;
            OUT_MSG("{\"status\":\"category_reset\",\"mask\":%d}", SC_CAT_ALL);
            return 0;
        }

        OUT_MSG("{\"error\":\"unknown cat command\"}");
        return -1;
    }

    /* ================================================================
     * hook slim / hook all / hook range <max_nr>
     * ================================================================ */
    if (str_starts_with(cmd, "hook ")) {
        param = skip_spaces(cmd + 5);

        if (strcmp(param, "slim") == 0) {
            int count = hook_install_slim();
            OUT_MSG("{\"status\":\"hooks_installed\",\"mode\":\"slim\",\"count\":%d}",
                    count);
            return 0;
        }

        if (strcmp(param, "all") == 0) {
            int count = hook_install_all();
            OUT_MSG("{\"status\":\"hooks_installed\",\"mode\":\"all\",\"count\":%d}",
                    count);
            return 0;
        }

        if (str_starts_with(param, "range ")) {
            int max_nr = simple_atoi(skip_spaces(param + 6));
            if (max_nr <= 0) {
                OUT_MSG("{\"error\":\"invalid range\"}");
                return -1;
            }
            int count = hook_install_range(max_nr);
            OUT_MSG("{\"status\":\"hooks_installed\",\"mode\":\"range\","
                    "\"max_nr\":%d,\"count\":%d}", max_nr, count);
            return 0;
        }

        OUT_MSG("{\"error\":\"unknown hook command\"}");
        return -1;
    }

    /* ================================================================
     * filelog enable / filelog disable / filelog path <path>
     * filelog truncate
     * ================================================================ */
    if (str_starts_with(cmd, "filelog ")) {
        param = skip_spaces(cmd + 7);

        if (strcmp(param, "enable") == 0) {
            file_logger_enable();
            g_config.file_log_enabled = 1;
            OUT_MSG("{\"status\":\"filelog_enabled\"}");
            return 0;
        }

        if (strcmp(param, "disable") == 0) {
            file_logger_disable();
            g_config.file_log_enabled = 0;
            OUT_MSG("{\"status\":\"filelog_disabled\"}");
            return 0;
        }

        if (str_starts_with(param, "path ")) {
            const char *path = skip_spaces(param + 5);
            if (strlen(path) == 0 || strlen(path) >= MAX_PATH_LEN) {
                OUT_MSG("{\"error\":\"invalid path\"}");
                return -1;
            }
            int ret = file_logger_set_path(path);
            if (ret == 0) {
                strncpy(g_config.file_log_path, path, MAX_PATH_LEN - 1);
                OUT_MSG("{\"status\":\"path_set\",\"path\":\"%s\"}", path);
            } else {
                OUT_MSG("{\"error\":\"failed to set path\"}");
            }
            return ret;
        }

        if (strcmp(param, "truncate") == 0) {
            int ret = file_logger_truncate();
            OUT_MSG("{\"status\":\"%s\"}",
                    ret == 0 ? "truncated" : "truncate_failed");
            return ret;
        }

        OUT_MSG("{\"error\":\"unknown filelog command\"}");
        return -1;
    }

    /* ================================================================
     * args on/off, caller on/off, bt on/off, retval on/off, antidebug on/off
     * ================================================================ */
    if (str_starts_with(cmd, "args ")) {
        param = skip_spaces(cmd + 5);
        if (strcmp(param, "on") == 0) { g_config.capture_args = 1; }
        else if (strcmp(param, "off") == 0) { g_config.capture_args = 0; }
        else { OUT_MSG("{\"error\":\"use on/off\"}"); return -1; }
        OUT_MSG("{\"status\":\"args_%s\"}", g_config.capture_args ? "on" : "off");
        return 0;
    }

    if (str_starts_with(cmd, "caller ")) {
        param = skip_spaces(cmd + 7);
        if (strcmp(param, "on") == 0) { g_config.capture_caller = 1; }
        else if (strcmp(param, "off") == 0) { g_config.capture_caller = 0; }
        else { OUT_MSG("{\"error\":\"use on/off\"}"); return -1; }
        OUT_MSG("{\"status\":\"caller_%s\"}", g_config.capture_caller ? "on" : "off");
        return 0;
    }

    if (str_starts_with(cmd, "bt ")) {
        param = skip_spaces(cmd + 3);
        if (strcmp(param, "on") == 0) { g_config.capture_backtrace = 1; }
        else if (strcmp(param, "off") == 0) { g_config.capture_backtrace = 0; }
        else { OUT_MSG("{\"error\":\"use on/off\"}"); return -1; }
        OUT_MSG("{\"status\":\"bt_%s\"}", g_config.capture_backtrace ? "on" : "off");
        return 0;
    }

    if (str_starts_with(cmd, "retval ")) {
        param = skip_spaces(cmd + 7);
        if (strcmp(param, "on") == 0) { g_config.capture_retval = 1; }
        else if (strcmp(param, "off") == 0) { g_config.capture_retval = 0; }
        else { OUT_MSG("{\"error\":\"use on/off\"}"); return -1; }
        OUT_MSG("{\"status\":\"retval_%s\"}", g_config.capture_retval ? "on" : "off");
        return 0;
    }

    if (str_starts_with(cmd, "antidebug ")) {
        param = skip_spaces(cmd + 10);
        if (strcmp(param, "on") == 0) { g_config.detect_antidebug = 1; }
        else if (strcmp(param, "off") == 0) { g_config.detect_antidebug = 0; }
        else { OUT_MSG("{\"error\":\"use on/off\"}"); return -1; }
        OUT_MSG("{\"status\":\"antidebug_%s\"}",
                g_config.detect_antidebug ? "on" : "off");
        return 0;
    }

    /* ================================================================
     * log read [count] / log clear
     * ================================================================ */
    if (str_starts_with(cmd, "log ")) {
        param = skip_spaces(cmd + 4);

        if (str_starts_with(param, "read")) {
            const char *count_str = skip_spaces(param + 4);
            int count = 1;
            if (*count_str != '\0')
                count = simple_atoi(count_str);
            if (count <= 0) count = 1;
            if (count > 64) count = 64;

            struct svc_event *events = (struct svc_event *)kp_malloc(
                sizeof(struct svc_event) * count);
            if (!events) {
                OUT_MSG("{\"error\":\"alloc failed\"}");
                return -1;
            }

            int got = event_logger_read_batch(events, count);
            int off = 0;
            int i;

            off += snprintf(out_msg + off, outlen - off,
                            "{\"count\":%d,\"events\":[", got);

            for (i = 0; i < got && off < outlen - 256; i++) {
                struct svc_event *e = &events[i];
                if (i > 0)
                    off += snprintf(out_msg + off, outlen - off, ",");
                off += snprintf(out_msg + off, outlen - off,
                    "{\"ts\":%llu,\"pid\":%d,\"tid\":%d,\"uid\":%u,"
                    "\"comm\":\"%s\",\"nr\":%d,\"ret\":%ld,"
                    "\"cat\":%d,\"antidebug\":%d,"
                    "\"pc\":\"0x%lx\",\"lr\":\"0x%lx\","
                    "\"module\":\"%s\",\"offset\":\"0x%lx\","
                    "\"bt_depth\":%d,\"detail\":\"%s\"}",
                    e->timestamp_ns, e->pid, e->tid, e->uid,
                    e->comm, e->syscall_nr, e->retval,
                    e->category, e->is_antidebug,
                    e->caller_pc, e->caller_lr,
                    e->caller_module, e->caller_offset,
                    e->backtrace_depth, e->detail);
            }

            off += snprintf(out_msg + off, outlen - off, "]}");
            kp_free(events);
            return 0;
        }

        if (strcmp(param, "clear") == 0) {
            event_logger_clear();
            OUT_MSG("{\"status\":\"log_cleared\"}");
            return 0;
        }

        OUT_MSG("{\"error\":\"unknown log command\"}");
        return -1;
    }

    /* ================================================================
     * maps refresh <pid> / maps clear
     * ================================================================ */
    if (str_starts_with(cmd, "maps ")) {
        param = skip_spaces(cmd + 5);

        if (str_starts_with(param, "refresh ")) {
            int pid_val = simple_atoi(skip_spaces(param + 8));
            if (pid_val <= 0) {
                OUT_MSG("{\"error\":\"invalid pid\"}");
                return -1;
            }
            int count = maps_cache_refresh(pid_val);
            OUT_MSG("{\"status\":\"refreshed\",\"pid\":%d,\"entries\":%d}",
                    pid_val, count);
            return 0;
        }

        if (strcmp(param, "clear") == 0) {
            maps_cache_clear();
            OUT_MSG("{\"status\":\"maps_cleared\"}");
            return 0;
        }

        OUT_MSG("{\"error\":\"unknown maps command\"}");
        return -1;
    }

    /* ================================================================
     * stats - 返回统计信息
     * ================================================================ */
    if (strcmp(cmd, "stats") == 0) {
        int pending;
        unsigned long long total, dropped;
        event_logger_get_stats(&pending, &total, &dropped);
        OUT_MSG("{\"total_events\":%llu,\"dropped\":%llu,"
                "\"antidebug\":%llu,\"filtered\":%llu,"
                "\"file_writes\":%llu,\"file_errors\":%llu,"
                "\"hooks\":%llu,\"pending\":%d}",
                g_stats.total_events, g_stats.dropped_events,
                g_stats.antidebug_events, g_stats.filtered_events,
                g_stats.file_log_writes, g_stats.file_log_errors,
                g_stats.hook_count, pending);
        return 0;
    }

    /* ================================================================
     * reset - 重置所有配置到默认值
     * ================================================================ */
    if (strcmp(cmd, "reset") == 0) {
        g_config.running = 0;
        g_config.pid_count = 0;
        g_config.filter_uid = -1;
        memset(g_config.filter_pkg, 0, MAX_PKG_LEN);
        memset(g_config.filter_comm, 0, MAX_COMM_LEN);
        g_config.category_mask = SC_CAT_ALL;
        g_config.filtered_syscall_count = 0;
        g_config.capture_args = 1;
        g_config.capture_caller = 1;
        g_config.capture_backtrace = 0;
        g_config.capture_retval = 1;
        g_config.detect_antidebug = 1;
        event_logger_clear();
        maps_cache_clear();
        OUT_MSG("{\"status\":\"reset_complete\"}");
        pr_info("[svc-tracer] configuration reset to defaults\n");
        return 0;
    }

    /* ================================================================
     * config dump - 导出完整配置
     * ================================================================ */
    if (str_starts_with(cmd, "config ")) {
        param = skip_spaces(cmd + 7);
        if (strcmp(param, "dump") == 0) {
            OUT_MSG("{\"version\":\"%s\",\"running\":%d,"
                    "\"pid_count\":%d,\"filter_uid\":%d,"
                    "\"filter_pkg\":\"%s\",\"filter_comm\":\"%s\","
                    "\"category_mask\":%d,\"syscall_filter_count\":%d,"
                    "\"capture_args\":%d,\"capture_caller\":%d,"
                    "\"capture_bt\":%d,\"capture_retval\":%d,"
                    "\"detect_antidebug\":%d,"
                    "\"file_log\":%d,\"file_log_path\":\"%s\"}",
                    SVC_TRACER_VERSION,
                    g_config.running, g_config.pid_count,
                    g_config.filter_uid, g_config.filter_pkg,
                    g_config.filter_comm,
                    g_config.category_mask, g_config.filtered_syscall_count,
                    g_config.capture_args, g_config.capture_caller,
                    g_config.capture_backtrace, g_config.capture_retval,
                    g_config.detect_antidebug,
                    g_config.file_log_enabled, g_config.file_log_path);
            return 0;
        }
        OUT_MSG("{\"error\":\"unknown config command\"}");
        return -1;
    }

    /* ================================================================
     * 未知命令
     * ================================================================ */
    OUT_MSG("{\"error\":\"unknown command\",\"cmd\":\"%s\"}", cmd);
    return -1;
}

/* ============================================================================
 * kpm_exit - 模块卸载清理
 * ============================================================================ */
static long kpm_exit(void *__user reserved)
{
    pr_info("[svc-tracer] unloading...\n");

    /* 停止监控 */
    g_config.running = 0;

    /* 销毁 hook 引擎 (移除所有 hook) */
    hook_engine_destroy();

    /* 关闭文件日志 */
    file_logger_close();

    /* 清理 maps 缓存 */
    maps_cache_destroy();

    /* 销毁事件缓冲区 */
    event_logger_destroy();

    pr_info("[svc-tracer] unloaded\n");
    return 0;
}

/* 注册 KPM 入口点 */
KPM_INIT(kpm_init);
KPM_CTL0(kpm_control0);
KPM_EXIT(kpm_exit);
